﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CC_project
{
    class Program:resources
    {
                

        static void Main(string[] args)
        {
            string text = System.IO.File.ReadAllText(@"C:\Users\rayan\Desktop\CC project\CC project\code.txt");
            string[] lines = text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            bool check = true;
            Console.WriteLine("LEXEME LIST");

            tokens tokenObj = new tokens();
            syntax sytaxObj = new syntax();                       

            for (int i = 0; i < lines.Length; i++)
            {

                
                if (!(tokenObj.tokenGenerator(lines[i])))
                {
                    check = false;
                    break;
                }
            }
            
            
            if (check)
            {
                Console.WriteLine("\n\n__________________________________________\n\n >>  SYMBOL TABLE << \n\n");
                foreach (SymbolTable item in symbolTable)
                {
                    Console.WriteLine(item.name + " | " + item.type + " | " + item.value );
                }
                Console.WriteLine("\n\n__________________________________________\n\n >>  TOKEN LIST << \n\n");
                printQueue(tokenList);
                sytaxObj.syntaxAnalyzer(tokenList);
            }
                
            Console.ReadKey();
            
        }        

        static void printQueue(Queue<String> list)
        {
            foreach (string item in list)
            {
                Console.Write(item + " | ");
            }

        }

        
    }
}
