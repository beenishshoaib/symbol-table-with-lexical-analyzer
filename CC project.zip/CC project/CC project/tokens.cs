﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CC_project
{
    class tokens:resources
    {
        public bool addVarOrConst(string temp)
        {

            if (Regex.IsMatch(temp, "^([a-zA-Z_][a-zA-Z_1-9]*)$"))
            {
                tokenList.Enqueue(temp + "T_VAR");
                Console.WriteLine("          | >> Token Created => " + temp + " << | ");
                tableEntry = true;
                if (tableEntry)
                {

                    tableValueName = temp;
                }

                return true;
            }
            else if (Regex.IsMatch(temp, "^([0-9][0-9]*)$"))
            {
                tokenList.Enqueue(temp + "T_INT_VAL");
                Console.WriteLine("          | >> Token Created => " + temp + " << | ");
                if (tableEntry)
                {
                    tableValueType = "INT";
                    tableValueValue = temp;
                    SymbolTable t = new SymbolTable(tableValueName, tableValueType, tableValueValue);
                    Console.WriteLine(t.name + " " + tableValueType + " " + tableValueValue + "______");
                    symbolTable.Add(t);

                    tableEntry = false;
                }
                return true;
            }
            else if (Regex.IsMatch(temp, "^([0-9][0-9]*[.]?[0-9]*)$"))
            {
                tokenList.Enqueue(temp + "T_FLOAT_VAL");
                Console.WriteLine("          | >> Token Created => " + temp + " << | ");
                if (tableEntry)
                {
                    tableValueType = "FLOAT";
                    tableValueValue = temp;

                    SymbolTable t = new SymbolTable(tableValueName, tableValueType, tableValueValue);
                    Console.WriteLine(t.name + " " + tableValueType + " " + tableValueValue + "______");
                    symbolTable.Add(t);

                    tableEntry = false;
                }
                return true;
            }
            else
            {
                Console.WriteLine("ERROR OCCURED");
                return false;
            }

        }

        public bool tokenGenerator(string text)
        {

            string[] lineWords = text.Split(' ');
            bool result = true;

            foreach (string item1 in lineWords)
            {
                string temp = "";
                int count = 0;
                foreach (char item in item1)
                {

                    Console.WriteLine(" | " + item + " | ");
                    count++;
                    if (punctuationSymbols.Contains(item + "") || assignmentOperators.Contains(item + "") ||
                       arithmeticOperators.Contains(item + "") || logicalOperators.Contains(item + ""))
                    {

                        if (elementPresentInList(temp, keywords))
                        {
                            tokenList.Enqueue(temp);
                            Console.WriteLine("          | >> Token Created => " + temp + " << | ");

                        }
                        else if (temp != "")
                        {

                            if (!addVarOrConst(temp))
                            {
                                Console.WriteLine("ERROR OCCURED");
                                break;
                            }

                        }

                        temp = "";
                        tokenList.Enqueue(item + "");
                        Console.WriteLine("          | >> Token Created => " + item + " << | ");

                    }

                    else
                    {
                        temp = temp + item;
                        if (count == item1.Length)
                        {
                            if (elementPresentInList(temp, keywords))
                            {
                                tokenList.Enqueue(temp);
                                Console.WriteLine("          | >> Token Created => " + temp + " << | ");
                            }
                            else if (temp != "")
                            {
                                result = addVarOrConst(temp);
                                if (!result)
                                {
                                    Console.WriteLine("ERROR OCCURED");
                                    break;
                                }


                            }
                        }
                    }
                }
                if (!result)
                    break;
            }

            return result;
        }

        public void printListString(List<string> list)
        {
            foreach (string item in list)
            {
                Console.Write(item + " | ");
            }
        }

        public Boolean elementPresentInList(string element, List<string> list)
        {
            if (list.Contains(element))
                return true;
            else
                return false;
        }
    }
}
