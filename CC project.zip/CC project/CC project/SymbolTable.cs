﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CC_project
{
    public class SymbolTable
    {
        public SymbolTable(string name, string type, string value)
        {
            this.name = name;
            this.type = type;
            this.value = value;
        }

        public string name
        {
            set;
            get;
        }

        public string type
        {
            set;
            get;
        }

        public string value
        {
            set;
            get;
        }
    }
}
