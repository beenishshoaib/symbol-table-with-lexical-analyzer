﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CC_project
{
    class syntax:resources
    {
        public void syntaxAnalyzer(Queue<string> queue)
        {
            Console.WriteLine("\n\n __________________________________________\n");
            Console.WriteLine("\n >>>  Analyzing each line formed by tokens   <<<\n\n");

            string item = "";
            while (true)
            {
                if (queue.Count == 0)
                {
                    break;
                }
                string temp = queue.Dequeue();
                item = item + temp;
                if (temp == "{" || temp == ";" || temp == "end" || temp == "}")
                {

                    string res = syntaxChecker(item);
                    if (res == "ERROR")
                    {
                        Console.WriteLine(res);
                        break;
                    }
                    else
                    {
                        Console.WriteLine(res);

                    }
                    item = "";
                }
            }

            if (BeginStart)
            {
                Console.WriteLine("ERROR : End not found");

            }
        }

        public string syntaxChecker(string val)
        {
            Console.WriteLine("\nSending > " + val);
            string beginLine = "^([b][e][g][i][n][(][)][{])$";
            string intAssignmentLine = "^([i][n][t][a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][=][0-9][0-9]*[T][_][I][N][T][_][V][A][L][;])$";
            string floatAssignmentLine = "^(([f][l][o][a][t])[a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][=][0-9][0-9]*[.]?[0-9]*[T][_][F][L][O][A][T][_][V][A][L][;])$";
            string operationLine = "^([a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][=][a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][+][a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][;])$";
            string printLine = "^([p][r][i][n][t][a-zA-Z_][a-zA-Z_0-9]*[T][_][V][A][R][;])$";
            string comparisonStatement = "^([a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R][<>][a-zA-Z_][a-zA-Z_1-9]*[T][_][V][A][R])$";
            string ifWithoutBracket = "^([i][f][(][a-zA-Z_][a-zA-Z_1-9]*[*][<>][a-zA-Z_][a-zA-Z_1-9]*[*][)][{])$";
            string elseWithBracket = "^([e][l][s][e][{])$";
            string elseWithoutBracket = "^([e][l][s][e])$";
            string endLine = "^([e][n][d])$";
            string endBracket = "^([}])$";


            if (Regex.IsMatch(val, beginLine))
            {
                if (BeginStart == false)
                {
                    BeginStart = true;
                    
                    bracketStack.Push('{');
                    return "Successfull";
                }
                else
                {
                    return "ERROR: MULTIPLE BEGIN FOUND";

                }
            }


            else if (Regex.IsMatch(val, endBracket) && BeginStart)
            {
                if (bracketStack.Count > 0)
                {
                    bracketStack.Pop();
                    
                    return "Successfull";
                }

                else
                    return "ERROR";
            }

            

            else if (Regex.IsMatch(val, endLine) && BeginStart)
            {
                if (BeginStart == false)
                {
                    return "ERROR : Begin not found";
                }
                else if(bracketStack.Count == 0)
                {
                    BeginStart = false;
                    return "SUCCESSFUL";
                }
                else
                {
                    return "ERROR : Brackets not found";
                }
            }

            else if (Regex.IsMatch(val, intAssignmentLine))
            {
                return "Successfull";
            }

            else if (Regex.IsMatch(val, floatAssignmentLine))
            {
                return "Successfull";
            }
            else if (Regex.IsMatch(val, operationLine))
            {
                string firstvar = val.Substring(0, val.IndexOf('=') - 5);
                string secondvar = val.Substring(val.IndexOf('=') + 1, ((val.IndexOf('+') - 5) - (val.IndexOf('=') + 1)));
                string thirddvar = val.Substring(val.IndexOf('+') + 1, ((val.IndexOf(';') - 5) - (val.IndexOf('+') + 1)));
                
                if (symbolTable.Find(x => x.name == firstvar) != null &&
                   symbolTable.Find(x => x.name == secondvar) != null &&
                   symbolTable.Find(x => x.name == thirddvar) != null)
                {
                    return "Successful";
                }

                else
                    return "ERROR: values not defined";
            }

            else if (val.Substring(0, 2) == "if" && val.Contains('{'))
            {
                int start = val.IndexOf('(');
                int end = val.LastIndexOf(')');
                int lineEnd = val.LastIndexOf('{');
                

                if (start == -1 || end == -1 || lineEnd == -1)
                    return "ERROR";
                else
                {
                    
                    int lenght = end - (start + 1);
                    string condition = val.Substring(start + 1, lenght);
                    bracketStack.Push('{');             

                    if (Regex.IsMatch(condition, comparisonStatement))
                    {
                        //-------------

                        //-------------

                        return "Successfull";
                    }
                    else
                    {
                        return "ERROR";
                    }
                }

            }
            else if (val.Substring(0, 2) == "if")
            {
                int start = val.IndexOf('(');
                int end = val.LastIndexOf(')');
                int lineEnd = val.LastIndexOf(';');
                int ifWithBracket = val.LastIndexOf('{');
                if (start == -1 || end == -1 || lineEnd == -1)
                    return "ERROR>";
                else
                {
                    int lenght = end - (start + 1);
                    string condition = val.Substring(start + 1, lenght);
                    
                    if (Regex.IsMatch(condition, comparisonStatement))
                    {
                        lenght = lineEnd - (end + 1);                        
                        return syntaxChecker(val.Substring(end + 1, lenght + 1));
                    }
                    else
                    {
                        return "ERROR>>";
                    }
                }
            }

            



            else if (Regex.IsMatch(val, printLine))
            {
                return "Successfull";
            }

            else if (val.Substring(0, 4) == "else")
            {
                int end = val.IndexOf(';');

                if (end != -1)
                {
                    int length = end - 4;
                    string statement = val.Substring(4, length + 1);

                    return syntaxChecker(statement);
                }
                else
                {
                    return "ERROR";
                }
            }


            else
            {
                return "ERROR";
            }


        }
    }
}
