﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CC_project
{
    public class resources
    {
        protected static bool tableEntry = false;
        protected static bool BeginStart = false;

        protected static string tableValueName;
        protected static string tableValueType;
        protected static string tableValueValue;

        protected static int bracket = 0;

        protected static List<string> keywords = new List<string> { "begin", "end", "int", "float", "if", "for", "else", "then", "print" };
        protected static List<string> punctuationSymbols = new List<string> { "{", "}", "(", ")", ",", ";" };
        protected static List<string> logicalOperators = new List<string> { ">", "<" };
        protected static List<string> assignmentOperators = new List<string> { "=" };
        protected static List<string> arithmeticOperators = new List<string> { "+" };
        protected static List<SymbolTable> symbolTable = new List<SymbolTable>();

        protected static Queue<string> tokenList = new Queue<string>();

        protected static Stack<char> bracketStack = new Stack<char>();
    }
}
